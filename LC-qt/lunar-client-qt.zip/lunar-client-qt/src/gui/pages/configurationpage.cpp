//
// Created by nils on 11/5/21.
//

#include "configurationpage.h"

ConfigurationPage::ConfigurationPage(Config& config, QWidget *parent) : config(config), QWidget(parent){
}
